﻿using System;
using System.Threading;
using System.Threading.Tasks;
using YoutubeChannelFinder.Core;

namespace YoutubeChannelFinder.Infrastructure.Decorators;

public sealed class RetryTimedModule<TIn, TOut> : IPipelineModule<TIn, TOut>
{
    private readonly IPipelineModule<TIn, TOut> _inner;
    private readonly int _maxRetries;
    private readonly TimeSpan _timeout;
    private readonly TimeSpan _delayBetweenRetries;

    public RetryTimedModule(
        IPipelineModule<TIn, TOut> inner,
        int maxRetries,
        TimeSpan timeout,
        TimeSpan? delayBetweenRetries = null)
    {
        if (maxRetries < 0)
            throw new ArgumentOutOfRangeException(nameof(maxRetries));

        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
        _maxRetries = maxRetries;
        _timeout = timeout;
        _delayBetweenRetries = delayBetweenRetries ?? TimeSpan.Zero;
    }

    public string Name => _inner.Name;

    public async Task<TOut> ExecuteAsync(
        TIn input,
        PipelineContext context)
    {
        for (int attempt = 0; attempt <= _maxRetries; attempt++)
        {
            using var timeoutCts =
                CancellationTokenSource.CreateLinkedTokenSource(
                    context.CancellationToken);

            timeoutCts.CancelAfter(_timeout);

            try
            {
                return await _inner.ExecuteAsync(
                    input,
                    context with { CancellationToken = timeoutCts.Token });
            }
            catch (OperationCanceledException)
                when (!context.CancellationToken.IsCancellationRequested &&
                      attempt < _maxRetries)
            {
                // timeout occurred, retry
            }
            catch (Exception)
                when (attempt < _maxRetries)
            {
                // transient failure, retry
            }

            if (_delayBetweenRetries > TimeSpan.Zero)
            {
                await Task.Delay(_delayBetweenRetries, context.CancellationToken);
            }
        }

        // Final attempt (let exception bubble)
        return await _inner.ExecuteAsync(input, context);
    }
}
