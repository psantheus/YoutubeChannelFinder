﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace YoutubeChannelFinder.Core;

public sealed class PipelineContext
{
    public Guid CorrelationId { get; } = Guid.NewGuid();

    // Logical identifier for the input (e.g. domain)
    public string InputId { get; init; } = string.Empty;

    // Shared state bag (use sparingly, prefer typed outputs)
    public IDictionary<string, object> Bag { get; } = new Dictionary<string, object>();

    public CancellationToken CancellationToken { get; init; }
}
